import employeeDetails from "./sampleData";
import React, { useState } from "react";

const EmployeeDetails = () => {
  const [activeTab, setActiveTab] = useState("personal");
  const employee = employeeDetails;

  const renderTabContent = () => {
    const renderKeyValue = (label, value) => (
      <div className="key-value-pair">
        <div className="key">{label}</div>
        <div className="value">{value}</div>
      </div>
    );

    switch (activeTab) {
      case "personal":
        return (
          <div className="details-section">
            {renderKeyValue("Employee Full Name:", employee.personal.fullName)}
            {renderKeyValue("Date of Birth:", employee.personal.dateOfBirth)}
            {renderKeyValue("Gender:", employee.personal.gender)}
            {renderKeyValue("Age:", employee.personal.age)}
            {renderKeyValue(
              "Current Address:",
              `${employee.personal.currentAddress.line1}, ${employee.personal.currentAddress.line2}, ${employee.personal.currentAddress.city}, ${employee.personal.currentAddress.pinCode}`
            )}
            {renderKeyValue(
              "Permanent Address:",
              `${employee.personal.permanentAddress.line1}, ${employee.personal.permanentAddress.line2}, ${employee.personal.permanentAddress.city}, ${employee.personal.permanentAddress.pinCode}`
            )}
            {renderKeyValue("Mobile:", employee.personal.mobile)}
            {renderKeyValue("Personal Mail:", employee.personal.personalMail)}
            {renderKeyValue(
              "Emergency Contact Name:",
              employee.personal.emergencyContact.name
            )}
            {renderKeyValue(
              "Emergency Contact Mobile:",
              employee.personal.emergencyContact.mobile
            )}
          </div>
        );
      case "professional":
        return (
          <div className="details-section">
            {renderKeyValue(
              "Employment Code:",
              employee.professional.employmentCode
            )}
            {renderKeyValue("Company Mail:", employee.professional.companyMail)}
            {renderKeyValue("Office Phone:", employee.professional.officePhone)}
            {renderKeyValue("City:", employee.professional.officeAddress.city)}
            {renderKeyValue(
              "Office Address:",
              `${employee.professional.officeAddress.line1}, ${employee.professional.officeAddress.line2}, ${employee.professional.officeAddress.pinCode}`
            )}
            {renderKeyValue(
              "Reporting Manager:",
              employee.professional.reportingManager
            )}
            {renderKeyValue("HR Name:", employee.professional.hrName)}
            {renderKeyValue(
              "Employment History:",
              employee.professional.employmentHistory
            )}
            {renderKeyValue(
              "Date of Joining:",
              employee.professional.joiningDate
            )}
          </div>
        );
      case "projects":
        return (
          <div className="details-section">
            {employee.projects.length > 0 ? (
              employee.projects.map((project, index) => (
                <div key={index} className="project-section">
                  <h4>Project {index + 1}</h4>
                  {renderKeyValue("Project Code:", project.code)}
                  {renderKeyValue("Start Date:", project.startDate)}
                  {renderKeyValue("End Date:", project.endDate)}
                  {renderKeyValue("Client/Project Name:", project.clientName)}
                  {renderKeyValue(
                    "Reporting Manager:",
                    project.reportingManager
                  )}
                </div>
              ))
            ) : (
              <p>No project details available.</p>
            )}
          </div>
        );
      case "finance":
        return (
          <div className="details-section">
            {renderKeyValue("PAN Card:", employee.finance.panCard)}
            {renderKeyValue("Aadhar Card:", employee.finance.aadharCard)}
            <fieldset>
              <legend>Bank Details</legend>
              {renderKeyValue(
                "Bank Name:",
                employee.finance.bankDetails.bankName
              )}
              {renderKeyValue("Branch:", employee.finance.bankDetails.branch)}
              {renderKeyValue(
                "IFSC Code:",
                employee.finance.bankDetails.ifscCode
              )}
            </fieldset>
            {renderKeyValue("CTC Breakup:", employee.finance.ctcBreakup)}
            <button
              type="button"
              onClick={() => alert("Download last 6 months payslips!")}
              className="download-payslips"
            >
              Download Payslips
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="employee-details-page">
      <div className="tab-navigation">
        <button
          className={activeTab === "personal" ? "active" : ""}
          onClick={() => setActiveTab("personal")}
        >
          Personal Details
        </button>
        <button
          className={activeTab === "professional" ? "active" : ""}
          onClick={() => setActiveTab("professional")}
        >
          Professional Details
        </button>
        <button
          className={activeTab === "projects" ? "active" : ""}
          onClick={() => setActiveTab("projects")}
        >
          Project Details
        </button>
        <button
          className={activeTab === "finance" ? "active" : ""}
          onClick={() => setActiveTab("finance")}
        >
          Finance
        </button>
      </div>
      {renderTabContent()}
    </div>
  );
};

export default EmployeeDetails;
