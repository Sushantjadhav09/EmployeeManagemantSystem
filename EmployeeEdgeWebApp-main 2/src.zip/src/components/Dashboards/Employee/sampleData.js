const employeeDetails = {
  personal: {
    fullName: "John Doe",
    dateOfBirth: "1990-01-01",
    gender: "Male",
    age: 34,
    currentAddress: {
      city: "New York",
      line1: "123 Main St",
      line2: "Apt 4B",
      pinCode: "10001",
    },
    permanentAddress: {
      city: "Los Angeles",
      line1: "456 Elm St",
      line2: "Unit 12",
      pinCode: "90001",
    },
    mobile: "1234567890",
    personalMail: "john.doe@example.com",
    emergencyContact: {
      name: "Jane Doe",
      mobile: "0987654321",
    },
  },
  professional: {
    employmentCode: "123456",
    companyMail: "john.doe@company.com",
    officePhone: "1234567890",
    officeAddress: {
      city: "San Francisco",
      line1: "789 Pine St",
      line2: "Suite 100",
      pinCode: "94101",
    },
    reportingManager: "manager@example.com",
    hrName: "HR Manager",
    employmentHistory: "ABC Corp (2015-2020), XYZ Inc (2020-Present)",
    joiningDate: "2020-01-15",
  },
  projects: [
    {
      code: "PROJ001",
      startDate: "2023-01-01",
      endDate: "2023-06-30",
      clientName: "Client A",
      reportingManager: "manager@example.com",
    },
    {
      code: "PROJ002",
      startDate: "2023-01-01",
      endDate: "2023-06-30",
      clientName: "Client A",
      reportingManager: "manager@example.com",
    },
  ],
  finance: {
    panCard: "ABCDE1234F",
    aadharCard: "1234 5678 9012",
    bankDetails: {
      bankName: "State Bank Of India",
      branch: "Pune",
      ifscCode: "SBIN00001234567",
    },
    ctcBreakup: "Basic: ₹5,00,000, Bonus: ₹50,000",
  },
};

export default employeeDetails;
