export default () => {
  const departmentsData = [
    {
      name: `Software Development`,
      description: `Software Development is the process of creating computer programs, applications and systems`,
    },
    {
      name: `Deployement`,
      description: `Deployement is the process of making a software system available for use`,
    },
  ];

  return (
    <div className="container">
      <table className="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Department</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {departmentsData.map((department, index) => {
            return (
              <tr key={index}>
                <td>{department.name}</td>
                <td>{department.description}</td>
                <td>
                  <button type="button" className="btn btn-primary me-3">
                    Update
                  </button>
                  <button type="button" className="btn btn-primary">
                    Remove
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
