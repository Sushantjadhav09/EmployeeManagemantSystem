import { Link, Outlet, useNavigate } from "react-router-dom";

export default () => {
  const navigate = useNavigate();

  return (
    <div className="container-fluid p-0">
      <header className="bg-info d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-4 mb-4 border-bottom">
        <div className="col-md-3 mb-2 mb-md-0 ms-2">
          <a
            href="#"
            className="d-inline-flex  align-items-center link-body-emphasis text-decoration-none"
          >
            <span className="fs-5 text-white">Employee Management System</span>
          </a>
        </div>

        <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
          <li>
            <Link className="nav-link px-2 link-secondary text-white" to="">
              Home
            </Link>
          </li>
          <li>
            <Link
              className="nav-link px-2 link-secondary text-white"
              to="employees/view"
            >
              View Employees
            </Link>
          </li>
          <li>
            <Link
              className="nav-link px-2 link-secondary text-white"
              to="employees/add"
            >
              Add Employee
            </Link>
          </li>
        </ul>

        <div className="col-md-3 text-end">
          <button
            type="button"
            className="btn btn-primary me-2"
            onClick={() => navigate("/")}
          >
            Logout
          </button>
        </div>
      </header>

      <Outlet />
    </div>
  );
};
