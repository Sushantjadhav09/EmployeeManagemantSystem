import { useEffect, useState } from "react";

export default () => {
  const states = [
    `Andhra Pradesh`,
    `Arunachal Pradesh`,
    `Assam`,
    `Bihar`,
    `Chhattisgarh`,
    `Goa`,
    `Gujarat`,
    `Haryana`,
    `Himachal Pradesh`,
    `Jharkhand`,
    `Karnataka`,
    `Kerala`,
    `Madhya Pradesh`,
    `Maharashtra`,
    `Manipur`,
    `Meghalaya`,
    `Mizoram`,
    `Nagaland`,
    `Odisha`,
    `Punjab`,
    `Rajasthan`,
    `Sikkim`,
    `Tamil Nadu`,
    `Telangana`,
    `Tripura`,
    `Uttar Pradesh`,
    `Uttarakhand`,
    `West Bengal`,
    `Andaman and Nicobar Islands`,
    `Chandigarh`,
    `Dadra and Nagar Haveli and Daman and Diu`,
    `Lakshadweep`,
    `Delhi`,
    `Puducherry`,
    `Jammu and Kashmir`,
    `Ladakh`,
  ];

  const initialValues = {
    fname: "",
    lname: "",
    birthDate: "",
    gender: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    pinCode: "",
    country: "",
    permAddress1: "",
    permAddress2: "",
    permCity: "",
    permState: "",
    permPinCode: "",
    permCountry: "",
    mobile: "",
    emergencyName: "",
    emergencyMobile: "",

    companyMail: "",
    officePhone: "",
    officeCity: "",
    officeAddress1: "",
    officeAddress2: "",
    officePinCode: "",
    reportingManager: "",
    hrName: "",
    employmentHistory: "",
    joiningDate: "",

    panCard: "",
    aadharCard: "",
    bankName: "",
    bankBranch: "",
    ifscCode: "",
    ctcBreakup: "",
  };

  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [sameAsCurrent, setSameAsCurrent] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
    console.log(formValues);
  };

  const handleCheckboxChange = (e) => {
    const { checked } = e.target;
    setSameAsCurrent(checked);

    if (checked) {
      setFormValues({
        ...formValues,
        permAddress1: formValues.address1,
        permAddress2: formValues.address2,
        permCity: formValues.city,
        permState: formValues.state,
        permPinCode: formValues.pinCode,
        permCountry: formValues.country,
      });
    } else {
      setFormValues({
        ...formValues,
        permAddress1: "",
        permAddress2: "",
        permCity: "",
        permState: "",
        permPinCode: "",
        permCountry: "",
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setIsSubmit(true);
  };

  useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
    }
  }, [formErrors]);

  const validate = (values) => {
    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobileRegex = /^[0-9]{10}$/;
    const phoneRegex = /^[0-9]{8,12}$/;
    const pinCodeRegex = /^[0-9]{6}$/;

    if (!values.fname) {
      errors.fname = "First name is required!";
    }
    if (!values.lname) {
      errors.lname = "Last name is required!";
    }
    if (!values.birthDate) {
      errors.birthDate = "Birth date is required!";
    }
    if (!values.gender) {
      errors.gender = "Gender is required!";
    }
    if (
      !values.address1 ||
      !values.address2 ||
      !values.city ||
      !values.state ||
      !values.pinCode ||
      !values.country
    ) {
      errors.address1 = "Address is required!";
    }
    if (
      !values.permAddress1 ||
      !values.permAddress2 ||
      !values.permCity ||
      !values.permState ||
      !values.permPinCode ||
      !values.permCountry
    ) {
      errors.permAddress1 = "permanent address is required!";
    }
    if (!values.mobile || !mobileRegex.test(values.mobile)) {
      errors.mobile = "Mobile number is required!";
    } else if (!mobileRegex.test(values.panCard)) {
      errors.mobile = "Mobile number should be 10 digits!";
    }

    if (!values.emergencyName || !values.emergencyMobile) {
      errors.emergencyName = "Emergency contact information is required!";
    }
    if (!mobileRegex.test(values.emergencyMobile)) {
      errors.emergencyMobile = "Mobile number should be 10 digits!";
    }

    if (!values.employmentCode || !/^[0-9]{6}$/.test(values.employmentCode)) {
      errors.employmentCode = "Employment code must be a 6-digit number!";
    }
    if (!values.companyMail || !emailRegex.test(values.companyMail)) {
      errors.companyMail = "Valid company email is required!";
    }
    if (!values.officePhone || !phoneRegex.test(values.officePhone)) {
      errors.officePhone = "Office phone must be between 8 and 12 digits!";
    }
    if (
      !values.officeAddress1 ||
      !values.officeAddress2 ||
      !values.officeCity ||
      !values.officePinCode ||
      !pinCodeRegex.test(values.officePinCode)
    ) {
      errors.officeAddress1 =
        "Complete office address with valid 6-digit pin code is required!";
    }
    if (!values.reportingManager) {
      errors.reportingManager =
        "Reporting manager's employee code or email is required!";
    }
    if (!values.hrName) {
      errors.hrName = "HR name is required!";
    }
    if (!values.employmentHistory) {
      errors.employmentHistory = "Employment history is required!";
    }
    if (!values.joiningDate) {
      errors.joiningDate = "Date of joining is required!";
    }

    if (!values.panCard) {
      errors.panCard = "PAN card is required!";
    } else if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(values.panCard)) {
      errors.panCard =
        "PAN card must be a valid 10-character alphanumeric code!";
    }

    if (!values.aadharCard) {
      errors.aadharCard = "Aadhar card is required!";
    } else if (!/^\d{12}$/.test(values.aadharCard)) {
      errors.aadharCard = "Aadhar card must be a 12-digit number!";
    }

    if (!values.bankName) {
      errors.bankName = "Bank name is required!";
    }

    if (!values.bankBranch) {
      errors.bankBranch = "Bank branch is required!";
    }

    if (!values.ifscCode) {
      errors.ifscCode = "IFSC code is required!";
    } else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(values.ifscCode)) {
      errors.ifscCode = "IFSC code must be a valid 11-character code!";
    }

    if (!values.ctcBreakup) {
      errors.ctcBreakup = "CTC breakup is required!";
    }
    return errors;
  };

  return (
    <div className="row justify-content-center my-5 mx-0 w-100">
      <div className="col-6">
        <form id="form" onSubmit={handleSubmit}>
          <div className="col-12 text-center">
            <label className="form-label fs-2">Employee personal details</label>{" "}
            <br />
          </div>
          <div className="form-group">
            <label htmlFor="fname" className="form-label">
              First name
            </label>
            <input
              type="text"
              className="form-control"
              id="fname"
              name="fname"
              value={formValues.fname}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.fname}</p>

            <label htmlFor="lname" className="form-label">
              Last name
            </label>
            <input
              type="text"
              className="form-control"
              id="lname"
              name="lname"
              value={formValues.lname}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.lname}</p>

            <label htmlFor="birthDate" className="form-label">
              Birthday
            </label>
            <input
              type="date"
              className="form-control"
              id="birthDate"
              name="birthDate"
              value={formValues.birthDate}
              onChange={handleChange}
            ></input>
            <p className="text-danger">{formErrors.birthDate}</p>
          </div>
          <div className="form-group">
            <label htmlFor="gender" className="form-label">
              Gender
            </label>
            <div className="form-check">
              <input
                type="radio"
                className="form-check-input"
                id="male"
                name="gender"
                value="Male"
                checked={formValues.gender === "Male"}
                onChange={handleChange}
              />
              <label htmlFor="male" className="form-check-label">
                Male
              </label>
            </div>

            <div className="form-check">
              <input
                type="radio"
                className="form-check-input"
                id="female"
                name="gender"
                value="Female"
                checked={formValues.gender === "Female"}
                onChange={handleChange}
              />
              <label htmlFor="female" className="form-check-label">
                Female
              </label>
            </div>

            <div className="form-check">
              <input
                type="radio"
                className="form-check-input"
                id="other"
                name="gender"
                value="Other"
                checked={formValues.gender === "Other"}
                onChange={handleChange}
              />
              <label htmlFor="other" className="form-check-label">
                Other
              </label>
            </div>
            <p className="text-danger">{formErrors.gender}</p>
          </div>
          <div className="form-group">
            <div className="col-12 text-center">
              <label className="form-label fs-5">Current address</label> <br />
            </div>
            <label className="form-label" htmlFor="address1">
              Address line 1
            </label>
            <input
              type="text"
              className="form-control"
              id="address1"
              name="address1"
              maxLength="50"
              value={formValues.address1}
              onChange={handleChange}
            />

            <label className="form-label" htmlFor="address2">
              Address line 2
            </label>
            <input
              type="text"
              className="form-control"
              id="address2"
              name="address2"
              maxLength="50"
              value={formValues.address2}
              onChange={handleChange}
            />

            <label className="form-label" htmlFor="city">
              City
            </label>
            <input
              type="text"
              className="form-control"
              id="city"
              name="city"
              maxLength="50"
              value={formValues.city}
              onChange={handleChange}
            />

            <div className="form-group">
              <label className="form-label" htmlFor="state">
                State
              </label>
              <select
                className="form-control"
                name="state"
                id="state"
                value={formValues.state}
                onChange={handleChange}
              >
                <option value="">Select a state</option>
                {states.map((state, index) => {
                  return (
                    <option key={index} value={state}>
                      {state}
                    </option>
                  );
                })}
              </select>
            </div>

            <label htmlFor="pinCode" className="form-label">
              Pin Code
            </label>
            <input
              type="number"
              className="form-control"
              id="pinCode"
              name="pinCode"
              maxLength="6"
              value={formValues.pinCode}
              onChange={handleChange}
            />

            <label htmlFor="country" className="form-label">
              Country
            </label>
            <input
              type="text"
              className="form-control"
              id="country"
              name="country"
              maxLength="50"
              value={formValues.country}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.address1}</p>
          </div>
          <div className="form-group">
            <div className="col-12 text-center">
              <label className="form-label fs-5">Permanent address</label>{" "}
              <br />
            </div>
            <div className="form-check">
              <input
                type="checkbox"
                className="form-check-input"
                id="sameAddress"
                name="sameAddress"
                value="sameAddress"
                checked={sameAsCurrent}
                onChange={handleCheckboxChange}
              />
              <label htmlFor="sameAddress" className="form-check-label">
                Permanent address is same as current address
              </label>
              <br></br>
            </div>{" "}
            <br />
            <label className="form-label" htmlFor="permAddress1">
              Address line 1
            </label>
            <input
              type="text"
              className="form-control"
              id="permAddress1"
              name="permAddress1"
              maxLength="50"
              value={formValues.permAddress1}
              onChange={handleChange}
            />
            <label className="form-label" htmlFor="permAddress2">
              Address line 2
            </label>
            <input
              type="text"
              className="form-control"
              id="permAddress2"
              name="permAddress2"
              maxLength="50"
              value={formValues.permAddress2}
              onChange={handleChange}
            />
            <label className="form-label" htmlFor="permCity">
              City
            </label>
            <input
              type="text"
              className="form-control"
              id="permCity"
              name="permCity"
              maxLength="50"
              value={formValues.permCity}
              onChange={handleChange}
            />
            <div className="form-group">
              <label className="form-label" htmlFor="permState">
                State
              </label>
              <select
                className="form-control"
                name="permState"
                id="permState"
                value={formValues.permState}
                onChange={handleChange}
              >
                <option value="">Select a state</option>
                {states.map((state, index) => {
                  return (
                    <option key={index} value={state}>
                      {state}
                    </option>
                  );
                })}
              </select>
            </div>
            <label htmlFor="permPinCode" className="form-label">
              Pin Code
            </label>
            <input
              type="number"
              className="form-control"
              id="permPinCode"
              name="permPinCode"
              maxLength="6"
              value={formValues.permPinCode}
              onChange={handleChange}
            />
            <label htmlFor="permCountry" className="form-label">
              Country
            </label>
            <input
              type="text"
              className="form-control"
              id="permCountry"
              name="permCountry"
              maxLength="50"
              value={formValues.permCountry}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.permAddress1}</p>
          </div>
          <label htmlFor="mobile" className="form-label">
            Mobile Number:
          </label>
          <input
            type="tel"
            className="form-control"
            id="mobile"
            name="mobile"
            placeholder="Enter your mobile number"
            value={formValues.mobile}
            onChange={handleChange}
          />
          <p className="text-danger">{formErrors.mobile}</p>
          <div className="form-group">
            <div className="col-12 text-center">
              <label className="form-label fs-5">
                Emergency contact information
              </label>{" "}
              <br />
            </div>

            <label htmlFor="emergencyName" className="form-label">
              Name:
            </label>
            <input
              type="text"
              className="form-control"
              id="emergencyName"
              name="emergencyName"
              value={formValues.emergencyName}
              onChange={handleChange}
            />

            <label htmlFor="emergencyMobile" className="form-label">
              Mobile Number:
            </label>
            <input
              type="tel"
              className="form-control"
              id="emergencyMobile"
              name="emergencyMobile"
              placeholder="Enter your mobile number"
              value={formValues.emergencyMobile}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.emergencyName}</p>
          </div>{" "}
          <br />
          <div className="form-group">
            <div className="col-12 text-center">
              <label className="form-label fs-2">
                Employee profesional details
              </label>{" "}
              <br />
            </div>

            <label htmlFor="employmentCode" className="form-label">
              Employment Code
            </label>
            <input
              type="number"
              className="form-control"
              id="employmentCode"
              name="employmentCode"
              value={formValues.employmentCode}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.employmentCode}</p>

            <label htmlFor="companyMail" className="form-label">
              Company Mail
            </label>
            <input
              type="email"
              className="form-control"
              id="companyMail"
              name="companyMail"
              value={formValues.companyMail}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.companyMail}</p>

            <label htmlFor="officePhone" className="form-label">
              Office Phone
            </label>
            <input
              type="tel"
              className="form-control"
              id="officePhone"
              name="officePhone"
              value={formValues.officePhone}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.officePhone}</p>

            <label htmlFor="officeAddress1" className="form-label">
              Office Address Line 1
            </label>
            <input
              type="text"
              className="form-control"
              id="officeAddress1"
              name="officeAddress1"
              value={formValues.officeAddress1}
              onChange={handleChange}
            />

            <label htmlFor="officeAddress2" className="form-label">
              Office Address Line 2
            </label>
            <input
              type="text"
              className="form-control"
              id="officeAddress2"
              name="officeAddress2"
              value={formValues.officeAddress2}
              onChange={handleChange}
            />

            <label htmlFor="officeCity" className="form-label">
              Office City
            </label>
            <input
              type="text"
              className="form-control"
              id="officeCity"
              name="officeCity"
              value={formValues.officeCity}
              onChange={handleChange}
            />

            <label htmlFor="officePinCode" className="form-label">
              Office Pin Code
            </label>
            <input
              type="text"
              className="form-control"
              id="officePinCode"
              name="officePinCode"
              value={formValues.officePinCode}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.officeAddress1}</p>

            <label htmlFor="reportingManager" className="form-label">
              Reporting Manager (Employee Code/Email)
            </label>
            <input
              type="text"
              className="form-control"
              id="reportingManager"
              name="reportingManager"
              value={formValues.reportingManager}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.reportingManager}</p>

            <label htmlFor="hrName" className="form-label">
              HR Name
            </label>
            <input
              type="text"
              className="form-control"
              id="hrName"
              name="hrName"
              value={formValues.hrName}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.hrName}</p>

            <label htmlFor="employmentHistory" className="form-label">
              Employment History
            </label>
            <textarea
              className="form-control"
              id="employmentHistory"
              name="employmentHistory"
              value={formValues.employmentHistory}
              onChange={handleChange}
            ></textarea>
            <p className="text-danger">{formErrors.employmentHistory}</p>

            <label htmlFor="joiningDate" className="form-label">
              Date of Joining
            </label>
            <input
              type="date"
              className="form-control"
              id="joiningDate"
              name="joiningDate"
              value={formValues.joiningDate}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.joiningDate}</p>
          </div>
          <div className="form-group">
            <div className="col-12 text-center">
              <label className="form-label fs-2">
                Employee finance details
              </label>{" "}
              <br />
            </div>

            <label htmlFor="panCard" className="form-label">
              PAN Card
            </label>
            <input
              type="text"
              className="form-control"
              id="panCard"
              name="panCard"
              value={formValues.panCard}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.panCard}</p>

            <label htmlFor="aadharCard" className="form-label">
              Aadhar Card
            </label>
            <input
              type="text"
              className="form-control"
              id="aadharCard"
              name="aadharCard"
              value={formValues.aadharCard}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.aadharCard}</p>

            <label htmlFor="bankName" className="form-label">
              Bank Name
            </label>
            <input
              type="text"
              className="form-control"
              id="bankName"
              name="bankName"
              value={formValues.bankName}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.bankName}</p>

            <label htmlFor="bankBranch" className="form-label">
              Bank Branch
            </label>
            <input
              type="text"
              className="form-control"
              id="bankBranch"
              name="bankBranch"
              value={formValues.bankBranch}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.bankBranch}</p>

            <label htmlFor="ifscCode" className="form-label">
              IFSC Code
            </label>
            <input
              type="text"
              className="form-control"
              id="ifscCode"
              name="ifscCode"
              value={formValues.ifscCode}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.ifscCode}</p>

            <label htmlFor="ctcBreakup" className="form-label">
              CTC Breakup
            </label>
            <textarea
              className="form-control"
              id="ctcBreakup"
              name="ctcBreakup"
              value={formValues.ctcBreakup}
              onChange={handleChange}
            />
            <p className="text-danger">{formErrors.ctcBreakup}</p>
          </div>
          <div className="col-12 text-center">
            <input className="btn btn-primary" type="submit" value="Submit" />
          </div>
        </form>
      </div>
    </div>
  );
};
