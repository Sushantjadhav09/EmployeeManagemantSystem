import AdminDashboard from "./Admin/Dashboard";
import EmployeeDashboard from "./Employee/Dashboard";
import LoginType from "../../datatype/LoginType";

export default () => {
  // const login = LoginType.ADMIN;
  const login = LoginType.EMPLOYEE;

  return (
    <div className="dashboard-page">
      {login === LoginType.EMPLOYEE ? (
        <EmployeeDashboard />
      ) : (
        <AdminDashboard />
      )}
    </div>
  );
};
