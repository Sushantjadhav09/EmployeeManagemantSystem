import React from 'react';


const HomePage = () => {
  return (
    <div className="home-page">
      <header className="header">
        <h1>Employee Management System</h1>
        <p>Manage your employees efficiently and effortlessly.</p>
      </header>

      <section className="stats">
        <div className="stat-card">
          <h2>120</h2>
          <p>Total Employees</p>
        </div>
        <div className="stat-card">
          <h2>10</h2>
          <p>Departments</p>
        </div>
        <div className="stat-card">
          <h2>5</h2>
          <p>New Hires This Month</p>
        </div>
      </section>

      <section className="actions">
        <button className="action-btn add-btn">Add Employee</button>
        <button className="action-btn view-btn">View Employees</button>
      </section>

      <footer className="footer">
        <p>&copy; 2024 Employee Management System. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
