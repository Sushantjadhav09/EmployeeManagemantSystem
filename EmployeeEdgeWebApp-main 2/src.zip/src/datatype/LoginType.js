const LoginType = {
  EMPLOYEE: "EMPLOYEE",
  ADMIN: "ADMIN",
};

export default LoginType;
