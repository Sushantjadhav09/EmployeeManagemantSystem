import { Routes, Route } from "react-router-dom";
import Login from "./components/LoginAndRegister/Login";
import Register from "./components/LoginAndRegister/Register";
import AdminDashboard from "./components/Dashboards/Admin/Dashboard";
import ViewEmployees from "./components/Dashboards/Admin/ViewEmployees/ViewEmployees";
import AddEmployee from "./components/Dashboards/Admin/AddEmployee/AddEmployee";
import HomePage from "./components/HomePage";
import Home from "./components/Dashboards/Home";

export default () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/home" element={<Home />} />
        <Route path="/home/employees/view" element={<ViewEmployees />} />
        <Route path="/home/employees/add" element={<AddEmployee />} />
      </Routes>
    </>
  );
};
